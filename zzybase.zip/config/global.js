global.name = "亥 Zbase";
global.number = "";
global.dev = process.env.NODE_ENV === "development";
global.locale = "id-ID";
global.timezone = "Asia/Jakarta";
global.commandPath = "./cmds";
global.creds = "./zzy/creds";
global.store = "./zzy/store.json";
global.prefix = ".";
global.splitArgs = "|";

global.owner = {
  name: "Zstore",
  number: ["6283890875133"],
  socialMedia: [
    {
      name: "YouTube",
      url: "https://youtube.com/@ZUU.00",
    },
  ],
};

global.mess = {
  dev: "ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ᴍᴀꜱɪʜ ᴅᴀʟᴀᴍ ᴛᴀʜᴀᴘ ᴘᴇɴɢᴇᴍʙᴀɴɢᴀɴ",
  onlyOwner: "ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪᴊᴀʟᴀɴᴋᴀɴ ᴏʟᴇʜ ᴏᴡɴᴇʀ",
  onlyGroup: "ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ʜᴀɴʏᴀ ʙɪꜱᴀ ᴅɪᴊᴀʟᴀɴᴋᴀɴ ᴅᴀʟᴀᴍ ɢʀᴏᴜᴘ",
};
