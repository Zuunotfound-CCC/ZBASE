module.exports = (options) => require("crypto").randomUUID(options);
