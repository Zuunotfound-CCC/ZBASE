module.exports = (max) => require("crypto").randomInt(max);
